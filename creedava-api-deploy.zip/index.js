// Azure Functions v4 Entry Point
// This file exports all function handlers for the v4 programming model

// Export individual functions
module.exports = {
  ...require('./getAnalytics'),
  ...require('./trackEvent'), 
  ...require('./submitContact'),
  ...require('./adminApi'),
  ...require('./health')
};

console.log('✅ Azure Functions loaded successfully');
